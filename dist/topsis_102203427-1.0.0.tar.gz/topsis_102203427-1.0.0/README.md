# TOPSIS Package (topsis_102203427)

This package implements the TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution) method for multi-criteria decision-making.

## Installation

Install the package using pip:

